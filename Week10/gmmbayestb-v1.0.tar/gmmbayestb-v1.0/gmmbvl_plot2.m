function gmmbvl_plot2(x)
%
% $Name:  $

plot(x(:,1),x(:,2),'b.');

 
