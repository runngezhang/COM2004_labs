%GMMB_VERSION  - Version string for GMMBayes toolbox
%
% version = gmmb_version();
%
% $Id: gmmb_version.m,v 1.2 2004/11/02 09:11:15 paalanen Exp $

function version = gmmb_version();

version = 'base3';
